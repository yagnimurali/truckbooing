package com.capgemini.truckbooking.exception;

public class TruckBooingException extends Exception{
	public TruckBooingException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
