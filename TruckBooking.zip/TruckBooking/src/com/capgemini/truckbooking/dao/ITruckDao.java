package com.capgemini.truckbooking.dao;

import java.util.List;


import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBooingException;

public interface ITruckDao {

	int getBookingId() throws TruckBooingException;
	List<TruckBean> retriveTruckDetailes() throws TruckBooingException;
	int bookTrucks(BookingBean bookingbean) throws TruckBooingException;
	public List<Integer> getTruckIds() throws TruckBooingException;
	public void updateNoOfTrucks(BookingBean be) throws TruckBooingException;
	public int getnoOfTrucks(int truckid) throws TruckBooingException;
}
