package com.capgemini.truckbooking.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = "INSERT INTO bookingdetails(bookingid,custid,custmobile,truckid,nooftrucks,dateoftransport) VALUES(booking_id_seq.nextval,?,?,1003,?,sysdate)";
	static String GET_TRUCKBOOK_ID = "SELECT booking_id_seq.CURRVAL FROM DUAL";
	static String RETRIVE_ALL_QUERY = "SELECT * FROM TruckDetails";
	static String GET_TRUCK_ID = "SELECT TRUCKID FROM TruckDetails";
	static String UPDATE_NO_OFTRUCKS = "update truckDetails set availablenos = (availablenos-?) where TRUCKID = ?";
	
	static String GET_NO_OF_TRUCKS_ID = "SELECT availablenos FROM truckDetails WHERE TRUCKID =?";
	 
}
