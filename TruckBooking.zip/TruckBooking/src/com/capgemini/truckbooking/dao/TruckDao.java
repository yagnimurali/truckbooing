package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBooingException;
import com.capgemini.truckbooking.util.DBConnecton;

public class TruckDao implements ITruckDao {
	
	static Connection conn;

	@Override
	public int getBookingId() throws TruckBooingException {
		
		PreparedStatement getPurchseStmt = null;
		ResultSet purchaseIdResult = null;
		int purchaseid = 0;
		try {
			conn = DBConnecton.getConnection();
			getPurchseStmt = conn.prepareStatement(IQueryMapper.GET_TRUCKBOOK_ID);
			purchaseIdResult = getPurchseStmt.executeQuery();
			if (purchaseIdResult.next()) {
				purchaseid = purchaseIdResult.getInt(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (TruckBooingException e) {
			throw new TruckBooingException("Sorry purchseid not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new TruckBooingException("Sorry purchseid sql exception genrated");

		}

		return purchaseid;
	}

	@Override
	public List<TruckBean> retriveTruckDetailes() throws TruckBooingException {
		
		
		conn = DBConnecton.getConnection();
		
		int mobilesCount = 0;

		PreparedStatement psMobStmt = null;
		ResultSet resultset = null;

		List<TruckBean> mobilesList = new ArrayList<TruckBean>();
		try {
			psMobStmt = conn.prepareStatement(IQueryMapper.RETRIVE_ALL_QUERY);
			resultset = psMobStmt.executeQuery();
			
			while (resultset.next()) {
				
				TruckBean truckbean = new TruckBean();
				truckbean.setTruckid(resultset.getInt(1));
				truckbean.setTrucktpe(resultset.getString(2));
				truckbean.setOrigin(resultset.getString(3));
				truckbean.setDestination(resultset.getString(4));
				truckbean.setCharges(resultset.getFloat(5));
				truckbean.setAvilableno(resultset.getInt(6));
				mobilesList.add(truckbean);

				mobilesCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new TruckBooingException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultset.close();
				psMobStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new TruckBooingException("Error in closing db connection");

			}
		}

		if (mobilesCount == 0)
			return null;
		else
			return mobilesList;
	}

	@Override
	public int bookTrucks(BookingBean bookingbean) throws TruckBooingException {
	
		BookingBean be = new BookingBean();
		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			//insertStmt.setInt(1, be.getBookingId());
			insertStmt.setString(1, be.getCustId());
			insertStmt.setString(2, be.getCustmobile());
			//insertStmt.setInt(3, be.getTruckId());
			insertStmt.setInt(3, be.getNoofTrucks());
			//insertStmt.setString(5,  null);
			


			int result = insertStmt.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new TruckBooingException("Sorry! insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {

			throw new TruckBooingException(e.getMessage());
		}

		return 1;
	}

	@Override
	public List<Integer> getTruckIds() throws TruckBooingException {
		
	
		conn = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		List<Integer> mobileIDsList = new ArrayList<Integer>();
		try {
			psMobIDStmt = conn.prepareStatement(IQueryMapper.GET_TRUCK_ID);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList.add(resultsetMobId.getInt(1));

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new TruckBooingException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new TruckBooingException("Error in closing db connection");

			}
	}
		

		if (mobileIDsCount == 0)
			return null;
		else
			return mobileIDsList;

}

	

	@Override
	public void updateNoOfTrucks(BookingBean be) throws TruckBooingException {
		 conn = DBConnecton.getConnection();
		PreparedStatement psUpdateQty = null;
		try {
			psUpdateQty = conn.prepareStatement(IQueryMapper.UPDATE_NO_OFTRUCKS);
			psUpdateQty.setInt(1, be.getNoofTrucks());
			psUpdateQty.setInt(2, be.getTruckId());
			
			int result = psUpdateQty.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new TruckBooingException("update filed");
			} else {
				conn.commit();
			}

		} catch (SQLException | TruckBooingException e) {
			throw new TruckBooingException("Quantity update not done");
		}

		
	}

	@Override
	public int getnoOfTrucks(int truckid) throws TruckBooingException {
		
		PreparedStatement getPurchseStmt = null;
		ResultSet purchaseIdResult = null;
		int purchaseid = 0;
		try {
			conn = DBConnecton.getConnection();
			getPurchseStmt = conn.prepareStatement(IQueryMapper.GET_NO_OF_TRUCKS_ID);
			getPurchseStmt.setInt(1, truckid);
			purchaseIdResult = getPurchseStmt.executeQuery();
			if (purchaseIdResult.next()) {
				purchaseid = purchaseIdResult.getInt(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (TruckBooingException e) {
			throw new TruckBooingException("Sorry purchseid not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new TruckBooingException("Sorry purchseid sql exception genrated");

		}

		return purchaseid;
	}
	}
