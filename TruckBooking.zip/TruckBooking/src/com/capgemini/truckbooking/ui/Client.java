package com.capgemini.truckbooking.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBooingException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;



public class Client {
	
	private static Scanner in;
	static ITruckService its = new TruckService();
	static TruckBean tb = new TruckBean();
	static BookingBean bb = new BookingBean();
		public static void main(String[] args) throws TruckBooingException {

			in = new Scanner(System.in);
			System.out.println(" \nWelcome to Truck Booking portal\n");
			while (true) {
				System.out.println(" \nEnter your choice:\n");
				System.out.println(" 1.Book A Truck\n");
				System.out.println(" 2.Exit\n");
				int choice = in.nextInt();
				switch (choice) {

				case 1:
					getInputs();
					break;

				case 2:
					System.out.println("\n\nThank you");
					System.exit(0);

				}

			}

		}
		
		
	



private static void getInputs() throws TruckBooingException {
	
	String custId;
	int truckid;
	int nooftruck;
	String mobileno;
	LocalDate datetrads;
			
	
	

	while (true) {
		in.nextLine();
		System.out.println("Enter customer ID ");

		custId = in.next();

		if (its.validateCustId(custId)) {
			break;
		} else {
			System.out.println("Invalid, should be [A-Z] and 6 digits ");
		}
	}

	

	datetrads = LocalDate.now();
	
			viewTrucks();

		/*
		 * while (true) { System.out.println("Please enter age ");
		 * 
		 * nooftruck = in.nextInt(); String Age = Integer.toString(age);
		 * 
		 * if (ida.validateAge(Age)) { break; } else {
		 * System.out.println("Invalid age"); } }
		 */

	
		while(true) {
		  System.out.println("Enter Truck Id"); 
		  truckid = in.nextInt();
		  
		  if (its.getTruckIds().contains(truckid)) { 
			  
			  
			  int avilnoOfTrucks =its.getnoOfTrucks(truckid);
			  System.out.println("Enter no of trucks");
			  
			  nooftruck = in.nextInt();
			  
			  if(nooftruck>0 && nooftruck<=avilnoOfTrucks) {
				  break;
			  }
			  else {
				  System.out.println("trucks quentity is not available");
			  }
			  
		  }
		  else {
			  System.out.println("plese select truck id from the above list");
		  }
		}
	
		while (true) {
			System.out.println("Enter phone number");

			mobileno = in.next();

			if (its.validateMobNumber(mobileno)) {
				break;
			} else {
				System.out.println("Invalid phone number");
			}
		}
		
		bb.setCustId(custId);
		bb.setTruckId(truckid);
		bb.setNoofTrucks(nooftruck);
		bb.setCustmobile(mobileno);
		bb.setDateofTran(null);
		its.bookTrucks(bb);
	its.updateNoOfTrucks(bb);
	System.out.println("Your Booking Id: "+its.getBookingId());
			
		}





private static void viewTrucks() {
	System.out.println("client error 1");
	try {
		List<TruckBean> mobilesList = new ArrayList<TruckBean>();
		mobilesList = its.retriveTruckDetailes();
System.out.println("client error");
		if (mobilesList != null) {
			System.out.println("method error");
			Iterator<TruckBean> i = mobilesList.iterator();
			while (i.hasNext()) {
				TruckBean obj = i.next();
				System.out.println(obj.getTruckid() + " " + obj.getTrucktpe() + " " + obj.getOrigin() + " "
						+ obj.getDestination() + " "+obj.getCharges()+" "+obj.getAvilableno()+"\n");

			}
		} else {
			System.out.println("\nNo trucks available!!\n");
		}

	} catch (TruckBooingException e) {

		System.out.println("Error  :" + e.getMessage());
	}

}







}
