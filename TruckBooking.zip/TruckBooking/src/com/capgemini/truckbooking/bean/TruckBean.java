package com.capgemini.truckbooking.bean;

public class TruckBean {
	private int truckid;
	
	private String trucktpe;
	private String origin;
	private String destination;
	private float charges;
	private int avilableno;

	public int getTruckid() {
		return truckid;
	}
	public void setTruckid(int truckid) {
		this.truckid = truckid;
	}
	public String getTrucktpe() {
		return trucktpe;
	}
	public void setTrucktpe(String trucktpe) {
		this.trucktpe = trucktpe;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	public int getAvilableno() {
		return avilableno;
	}
	public void setAvilableno(int avilableno) {
		this.avilableno = avilableno;
	}
}
