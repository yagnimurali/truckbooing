package com.capgemini.truckbooking.bean;

import java.time.LocalDate;

public class BookingBean {

	private int bookingId;
	private String custId;
	private String custmobile; 
	private int truckId;
	private int noofTrucks;
	private LocalDate dateofTran;
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustmobile() {
		return custmobile;
	}
	public void setCustmobile(String custmobile) {
		this.custmobile = custmobile;
	}
	public int getTruckId() {
		return truckId;
	}
	public void setTruckId(int truckId) {
		this.truckId = truckId;
	}
	public int getNoofTrucks() {
		return noofTrucks;
	}
	public void setNoofTrucks(int noofTrucks) {
		this.noofTrucks = noofTrucks;
	}
	public LocalDate getDateofTran() {
		return dateofTran;
	}
	public void setDateofTran(LocalDate dateofTran) {
		this.dateofTran = dateofTran;
	}
	
}
