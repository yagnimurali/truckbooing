package com.capgemini.truckbooking.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.TruckBooingException;

public class TruckService  implements ITruckService{
	
	ITruckDao itd = new TruckDao();

	@Override
	public List<TruckBean> retriveTruckDetailes() throws TruckBooingException {
		System.out.println("service not fine");
		List<TruckBean> trucks =null;
				trucks =itd.retriveTruckDetailes();
		System.out.println("service fine");
		// TODO Auto-generated method stub
		return trucks;
	}

	@Override
	public int bookTrucks(BookingBean bookingbean) throws TruckBooingException {
		// TODO Auto-generated method stub
		int book =itd.bookTrucks(bookingbean);
		return book;
	}

	@Override
	public boolean validateCustId(String custname) {
		String patterns = "[A-Z][0-9]{1,6}";
		if (Pattern.matches(patterns, custname)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateMobNumber(String PhoneNumber) {
		String patterns1 = "\\d{10}";
		if (Pattern.matches(patterns1, PhoneNumber)) {
			return true;
		} else {

			return false;
		}
	}

	@Override
	public int getBookingId() throws TruckBooingException {
		// TODO Auto-generated method stub
		int bookid = itd.getBookingId();
		return bookid;
	}

	@Override
	public List<Integer> getTruckIds() throws TruckBooingException {
		// TODO Auto-generated method stub
		List<Integer> truckid =itd.getTruckIds();
		
		return truckid;
	}

	@Override
	public void updateNoOfTrucks(BookingBean be) throws TruckBooingException {
		// TODO Auto-generated method stub
		itd.updateNoOfTrucks(be);
		
	}

	@Override
	public int getnoOfTrucks(int truckid) throws TruckBooingException {
		// TODO Auto-generated method stub
		int noOfTrucks = itd.getnoOfTrucks(truckid);
		return noOfTrucks;
	}

}
